package com.bank.service;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.entity.Account;
import com.bank.repository.AccountRepository;

@Service
public class BankService {

    @Autowired
    private AccountRepository accountRepository;

    public Optional<Account> getAccountByNumber(long accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber);
    }

    public String checkBalance(long accountNumber) {
        Optional<Account> accountOpt = getAccountByNumber(accountNumber);
        return accountOpt.map(account -> "Balance: " + account.getBalance())
                         .orElse("Account not found!");
    }

    public String debitAmount(long accountNumber, BigDecimal amount) {
        Optional<Account> accountOpt = getAccountByNumber(accountNumber);
        if (accountOpt.isPresent()) {
            Account account = accountOpt.get();
            if (account.getBalance().compareTo(amount) >= 0) {
                account.setBalance(account.getBalance().subtract(amount));
                accountRepository.save(account);
                return "Debited " + amount + ". New balance: " + account.getBalance();
            } else {
                return "Insufficient funds. Current balance: " + account.getBalance();
            }
        }
        return "Account not found!";
    }

    public String creditAmount(long accountNumber, BigDecimal amount) {
        Optional<Account> accountOpt = getAccountByNumber(accountNumber);
        if (accountOpt.isPresent()) {
            Account account = accountOpt.get();
            account.setBalance(account.getBalance().add(amount));
            accountRepository.save(account);
            return "Credited " + amount + ". New balance: " + account.getBalance();
        }
        return "Account not found!";
    }
}
