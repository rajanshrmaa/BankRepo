package com.bankmanagement.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountNumber;
    private double balance;
	public void setAccountNumber(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setBalance(double d) {
		// TODO Auto-generated method stub
		
	}
	public double getBalance() {
		// TODO Auto-generated method stub
		return 0;
	}
}
