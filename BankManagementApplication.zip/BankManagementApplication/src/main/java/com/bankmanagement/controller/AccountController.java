package com.bankmanagement.controller;

import com.bankmanagement.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping("/deposit")
    public String deposit(@RequestParam String accountNumber, @RequestParam double amount, Model model) {
        double balance = accountService.deposit(accountNumber, amount);
        model.addAttribute("message", "Deposit successful!");
        model.addAttribute("balance", balance);
        return "account";
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam String accountNumber, @RequestParam double amount, Model model) {
        try {
            double balance = accountService.withdraw(accountNumber, amount);
            model.addAttribute("message", "Withdrawal successful!");
            model.addAttribute("balance", balance);
        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
        }
        return "account";
    }
}
