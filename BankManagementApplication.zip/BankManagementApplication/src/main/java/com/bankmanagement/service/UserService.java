package com.bankmanagement.service;

import com.bankmanagement.model.Account;
import com.bankmanagement.model.User;
import com.bankmanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        Account account = new Account();
        account.setAccountNumber("ACC" + System.currentTimeMillis());
        account.setBalance(0.0);
        user.setAccount(account);

        return userRepository.save(user);
    }

    public User loginUser(String email, String password) {
        User user = userRepository.findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        throw new RuntimeException("Invalid credentials");
    }
}
