package com.bankmanagement.service;

import com.bankmanagement.model.Account;
import com.bankmanagement.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    public Account getAccountDetails(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber);
    }

    public double deposit(String accountNumber, double amount) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRepository.save(account);
            return account.getBalance();
        }
        throw new RuntimeException("Account not found");
    }

    public double withdraw(String accountNumber, double amount) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        if (account != null) {
            if (account.getBalance() >= amount) {
                account.setBalance(account.getBalance() - amount);
                accountRepository.save(account);
                return account.getBalance();
            } else {
                throw new RuntimeException("Insufficient balance");
            }
        }
        throw new RuntimeException("Account not found");
    }

	
}
