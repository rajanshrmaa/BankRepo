package com.bank.controller;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bank.entity.AccountHolder;
import com.bank.service.AccountHolderService;
@RestController
@RequestMapping("/api/account")
public class AccountController {

    @Autowired
    private AccountHolderService accountHolderService;

    @PostMapping("/register")
    public AccountHolder register(@RequestBody AccountHolder accountHolder) {
        return accountHolderService.register(accountHolder);
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestParam String name, @RequestParam String password) {
        Optional<AccountHolder> accountHolder = accountHolderService.login(name, password);
        if(accountHolder.isPresent()) {
            return ResponseEntity.ok("Login successful!");
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials!");
    }

    @PostMapping("/update")
    public AccountHolder updateDetails(@RequestParam Long id, @RequestParam String name, @RequestParam String phone) {
        return accountHolderService.updateDetails(id, name, phone);
    }

    @PostMapping("/debit")
    public String debit(@RequestParam Long id, @RequestParam Double amount) {
        return accountHolderService.debitAmount(id, amount);
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam Long id, @RequestParam Double amount) {
        return accountHolderService.depositAmount(id, amount);
    }
}
