package com.bank.service;

import com.bank.entity.AccountHolder;
import com.bank.repository.AccountHolderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class AccountHolderService {

    @Autowired
    private AccountHolderRepository accountHolderRepository;

    public AccountHolder register(AccountHolder accountHolder) {
        return accountHolderRepository.save(accountHolder);
    }

    public Optional<AccountHolder> login(String name, String password) {
        return accountHolderRepository.findByNameAndPassword(name, password);
    }

    public AccountHolder updateDetails(Long id, String name, String phone) {
        AccountHolder accountHolder = accountHolderRepository.findById(id).orElseThrow();
        accountHolder.setName(name);
        accountHolder.setPhone(phone);
        return accountHolderRepository.save(accountHolder);
    }

    public String debitAmount(Long id, Double amount) {
        AccountHolder accountHolder = accountHolderRepository.findById(id).orElseThrow();
        if(accountHolder.getBalance() < amount) {
            return "Insufficient balance!";
        } else {
            accountHolder.setBalance(accountHolder.getBalance() - amount);
            accountHolderRepository.save(accountHolder);
            return "Amount debited. New balance: " + accountHolder.getBalance();
        }
    }

    public String depositAmount(Long id, Double amount) {
        AccountHolder accountHolder = accountHolderRepository.findById(id).orElseThrow();
        accountHolder.setBalance(accountHolder.getBalance() + amount);
        accountHolderRepository.save(accountHolder);
        return "Amount credited. New balance: " + accountHolder.getBalance();
    }
}
