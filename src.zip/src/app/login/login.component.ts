import { Component } from '@angular/core';
import { AccountService } from '../services/account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  credentials = { name: '', password: '' };

  constructor(private accountService: AccountService, private router: Router) { }

  onSubmit() {
    this.accountService.login(this.credentials.name, this.credentials.password).subscribe(
      response => {
        alert('Login successful!');
        this.router.navigate(['/account-details']);
      },
      error => {
        alert('Login failed. Please check your credentials.');
        console.error(error);
      }
    );
  }
}
